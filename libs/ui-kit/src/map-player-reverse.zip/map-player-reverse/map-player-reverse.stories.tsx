import { Story, Meta } from '@storybook/react';
import MapPlayerReverse, { MapPlayerReverseProps } from "./map-player-reverse";

export default {
  component: MapPlayerReverse,
  title: 'MapPlayerReverse',
} as Meta;


const sourceUrl = `https://localhost:3000/parser/proxy-file?file=F:\\\\beat-saber-files\\\\15e8\\\\zip.zip`;

const Template: Story<MapPlayerReverseProps> = (args) => <MapPlayerReverse {...args} />;

export const Primary = Template.bind({});
Primary.args = {
  sourceUrl,
};
