import styles from './map-player-reverse.module.scss';
import { useEffect } from "react";

/* eslint-disable-next-line */
export interface MapPlayerReverseProps {}

export function MapPlayerReverse(props: MapPlayerReverseProps) {
  useEffect(() => {
    import('./assets/app.bundle').then(res => {
      console.log('xxx res', res);
    })
  }, [])

  return (
    <div className={styles.container}>
      <canvas id="main"></canvas>
      <div id="banners"></div>
      <div id="navbar">
        <div className="background"></div>
        <div className="navtitle">
          <span id="songauthor"></span>
          <span id="songname"></span>
          <span id="songsubname"></span>
          <span id="levelauthor"></span>
        </div>
        <span className="navelement clickable" id="play">
            <i className="fas fa-play" id="play-button"></i>
        </span>
        <span className="navelement clickable" id="volume">
            <i className="fas fa-volume-up" id="volume-button"></i>
            <div id="volume-container" className="volume-container">
                <div id="volume-content" className="volume-content clickable">
                    <div className="volume-background"></div><div className="volume-progress"></div>
                </div>
            </div>
        </span>
        <span className="navelement" id="time">0:00</span>
        <span className="navelement timeline clickable" id="timeline">
          <div className="timelinebackground"></div>
          <div className="timelineprogress"></div>
          <div className="timelinepreview" id="timelinepreview">0:00</div>
        </span>
        <span className="navelement navselect rhs" id="difficulty">
            <select id="difficultyselect"></select>
        </span>
        <span className="navelement navselect rhs" id="mode">
            <select id="modeselect"></select>
        </span>
      </div>
      <div id="settings">
        <i className="fas fa-cog" id="settings-button"></i>
        <div id="settings-container" className="settings-container">
          <div id="settings-content" className="settings-content">
            <span className="settings-label">Anti-Aliasing</span>
            <select id="settings-antialiasing" className="settings-element">
              <option value="none">None</option>
              <option value="fxaa">FXAA</option>
              <option value="smaa">SMAA</option>
            </select><br/>
            <input type="checkbox" id="settings-hitsounds" className="settings-element"/>
            <span className="settings-label">Hitsounds</span><br/>
            <input type="checkbox" id="settings-static-lights" className="settings-element"/>
            <span className="settings-label">Static lights</span><br/>
            <input type="checkbox" id="settings-hide-notes" className="settings-element"/>
            <span className="settings-label">Hide notes</span><br/>
            <input type="checkbox" id="settings-hide-obstacles" className="settings-element"/>
            <span className="settings-label">Hide obstacles</span><br/>
            <a href="#" id="open-beatsaver-anchor" target="_parent">
              <button type="button" id="open-beatsaver" className="settings-element">
                Open on BeatSaver
              </button>
            </a>
            <a href="#" id="open-beastsaber-anchor" target="_parent">
              <button type="button" id="open-beastsaber" className="settings-element">
                Open on BeastSaber
              </button>
            </a>
            <button type="button" id="copy-link" className="settings-element">Copy link</button>
            <br/>
              <button type="button" id="copy-link-with-time" className="settings-element">
                Copy link with time
              </button>
              <br/>
              <div id="stats"></div>
          </div>
        </div>
      </div>
      <div id="environment">
        <div id="environment-container" className="settings-container">
          <div id="environment-content" className="settings-content">
            <span className="settings-label">Environment Detail</span>
            <select id="environment-detail" className="settings-element">
              <option value="none">None</option>
              <option value="low">Low</option>
              <option value="default">Default</option>
              <option value="bright">Bright</option>
            </select>
          </div>
        </div>
      </div>
      <div id="loading">
        <p>loading...</p>
        <div id="loadingbarbackground">
          <div id="loadingbarprogress"></div>
        </div>
        <div id="loadingstatus"></div>
      </div>
    </div>
  );
}

export default MapPlayerReverse;
